package com.trade.plugin;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;

public class TradeGUI {

    // Slot düzeni (54 slotluk envanter):
    // 0-12  -> Kendi eşyaların (13 slot)
    // 13    -> Ayırıcı
    // 14-26 -> Karşı tarafın eşyaları (13 slot, sadece görüntü)
    // 27-44 -> Bilgi/kontrol alanı
    // 45    -> XP ekle butonu
    // 46    -> XP sil butonu
    // 47    -> Boş
    // 48    -> Onay butonu
    // 49    -> İptal butonu
    // 50-53 -> Boş

    public static final int[] MY_SLOTS = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};
    public static final int[] THEIR_SLOTS = {14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26};
    public static final int SEPARATOR_SLOT = 13;
    public static final int XP_ADD_SLOT = 45;
    public static final int XP_REMOVE_SLOT = 46;
    public static final int CONFIRM_SLOT = 48;
    public static final int CANCEL_SLOT = 49;

    public static void openTradeGUI(TradePlugin plugin, TradeSession session, Player player) {
        Player other = session.getOther(player);
        String title = "§6§l⇄ §fTrade: §a" + player.getName() + " §7↔ §c" + other.getName();
        Inventory inv = Bukkit.createInventory(null, 54, title);

        fillGUI(inv, session, player);
        player.openInventory(inv);
    }

    public static void updateGUI(TradeSession session, Player player) {
        if (player.getOpenInventory() == null) return;
        Inventory inv = player.getOpenInventory().getTopInventory();
        if (inv == null) return;

        Player other = session.getOther(player);
        String title = "§6§l⇄ §fTrade: §a" + player.getName() + " §7↔ §c" + other.getName();
        if (!player.getOpenInventory().getTitle().equals(title)) return;

        fillGUI(inv, session, player);
    }

    private static void fillGUI(Inventory inv, TradeSession session, Player player) {
        // Temizle
        inv.clear();

        Player other = session.getOther(player);

        // Ayırıcı
        ItemStack separator = createItem(Material.BLACK_STAINED_GLASS_PANE, "§r");
        for (int i = 0; i < 54; i++) {
            if (!isMySlot(i) && !isTheirSlot(i)) {
                inv.setItem(i, separator);
            }
        }

        // Kendi eşyaları
        java.util.List<ItemStack> myItems = session.getMyItems(player);
        for (int i = 0; i < MY_SLOTS.length; i++) {
            if (i < myItems.size()) {
                inv.setItem(MY_SLOTS[i], myItems.get(i));
            } else {
                inv.setItem(MY_SLOTS[i], createItem(Material.LIME_STAINED_GLASS_PANE, "§a§lSenin Eşyaların"));
            }
        }

        // Karşı tarafın eşyaları (görüntü)
        java.util.List<ItemStack> theirItems = session.getTheirItems(player);
        for (int i = 0; i < THEIR_SLOTS.length; i++) {
            if (i < theirItems.size()) {
                inv.setItem(THEIR_SLOTS[i], theirItems.get(i).clone());
            } else {
                inv.setItem(THEIR_SLOTS[i], createItem(Material.RED_STAINED_GLASS_PANE, "§c§l" + other.getName() + "'in Eşyaları"));
            }
        }

        // XP bilgisi - kendi
        int myXP = session.getMyXP(player);
        int theirXP = session.getTheirItems(player) != null ? (player.equals(session.getSender()) ? session.getReceiverXP() : session.getSenderXP()) : 0;
        theirXP = player.equals(session.getSender()) ? session.getReceiverXP() : session.getSenderXP();

        ItemStack myXPItem = createItem(Material.EXPERIENCE_BOTTLE,
                "§a§lSenin XP'n: §f" + myXP,
                "§7Teklif ettiğin XP miktarı",
                "§eKliklayarak değiştir"
        );
        inv.setItem(27, myXPItem);

        ItemStack theirXPItem = createItem(Material.EXPERIENCE_BOTTLE,
                "§c§l" + other.getName() + "'in XP'si: §f" + theirXP,
                "§7Karşı tarafın teklif ettiği XP"
        );
        inv.setItem(28, theirXPItem);

        // XP butonları
        inv.setItem(XP_ADD_SLOT, createItem(Material.LIME_DYE, "§a§l+ XP Ekle",
                "§7Trade'e XP eklemek için tıkla",
                "§7Sol klik: +1 XP",
                "§7Sağ klik: +10 XP",
                "§7Shift+Sol: +100 XP"
        ));
        inv.setItem(XP_REMOVE_SLOT, createItem(Material.RED_DYE, "§c§l- XP Çıkar",
                "§7Trade'den XP çıkarmak için tıkla",
                "§7Sol klik: -1 XP",
                "§7Sağ klik: -10 XP",
                "§7Shift+Sol: -100 XP"
        ));

        // Onay butonu
        boolean myConfirmed = session.isConfirmed(player);
        boolean theirConfirmed = session.isConfirmed(other);

        Material confirmMat = myConfirmed ? Material.LIME_WOOL : Material.GREEN_WOOL;
        String confirmText = myConfirmed ? "§a§l✔ ONAYLANDI" : "§a§lONAYLA";
        inv.setItem(CONFIRM_SLOT, createItem(confirmMat, confirmText,
                myConfirmed ? "§7Onayın alındı!" : "§7Trade'i onaylamak için tıkla",
                theirConfirmed ? "§a" + other.getName() + " onayladı ✔" : "§c" + other.getName() + " henüz onaylamadı"
        ));

        // İptal butonu
        inv.setItem(CANCEL_SLOT, createItem(Material.BARRIER, "§c§lİPTAL ET",
                "§7Trade'i iptal etmek için tıkla"
        ));
    }

    private static boolean isMySlot(int slot) {
        for (int s : MY_SLOTS) if (s == slot) return true;
        return false;
    }

    private static boolean isTheirSlot(int slot) {
        for (int s : THEIR_SLOTS) if (s == slot) return true;
        return false;
    }

    public static boolean isMySlotPublic(int slot) { return isMySlot(slot); }
    public static boolean isTheirSlotPublic(int slot) { return isTheirSlot(slot); }

    private static ItemStack createItem(Material material, String name, String... lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            if (lore.length > 0) {
                meta.setLore(Arrays.asList(lore));
            }
            item.setItemMeta(meta);
        }
        return item;
    }
}

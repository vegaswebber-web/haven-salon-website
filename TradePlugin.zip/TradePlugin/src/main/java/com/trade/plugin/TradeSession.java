package com.trade.plugin;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class TradeSession {

    public enum State {
        PENDING,    // İstek gönderildi, bekleniyor
        TRADING,    // Trade ekranı açık
        CONFIRMED,  // Bir oyuncu onayladı
        COMPLETED,  // Trade tamamlandı
        CANCELLED   // Trade iptal edildi
    }

    private final Player sender;
    private final Player receiver;
    private State state;

    private final List<ItemStack> senderItems = new ArrayList<>();
    private final List<ItemStack> receiverItems = new ArrayList<>();

    private int senderXP = 0;
    private int receiverXP = 0;

    private boolean senderConfirmed = false;
    private boolean receiverConfirmed = false;

    public TradeSession(Player sender, Player receiver) {
        this.sender = sender;
        this.receiver = receiver;
        this.state = State.PENDING;
    }

    public Player getSender() { return sender; }
    public Player getReceiver() { return receiver; }
    public State getState() { return state; }
    public void setState(State state) { this.state = state; }

    public List<ItemStack> getSenderItems() { return senderItems; }
    public List<ItemStack> getReceiverItems() { return receiverItems; }

    public int getSenderXP() { return senderXP; }
    public void setSenderXP(int xp) { this.senderXP = xp; senderConfirmed = false; receiverConfirmed = false; }

    public int getReceiverXP() { return receiverXP; }
    public void setReceiverXP(int xp) { this.receiverXP = xp; senderConfirmed = false; receiverConfirmed = false; }

    public boolean isSenderConfirmed() { return senderConfirmed; }
    public boolean isReceiverConfirmed() { return receiverConfirmed; }

    public void setSenderConfirmed(boolean confirmed) { this.senderConfirmed = confirmed; }
    public void setReceiverConfirmed(boolean confirmed) { this.receiverConfirmed = confirmed; }

    public boolean bothConfirmed() { return senderConfirmed && receiverConfirmed; }

    public Player getOther(Player player) {
        return player.equals(sender) ? receiver : sender;
    }

    public List<ItemStack> getMyItems(Player player) {
        return player.equals(sender) ? senderItems : receiverItems;
    }

    public List<ItemStack> getTheirItems(Player player) {
        return player.equals(sender) ? receiverItems : senderItems;
    }

    public int getMyXP(Player player) {
        return player.equals(sender) ? senderXP : receiverXP;
    }

    public void setMyXP(Player player, int xp) {
        if (player.equals(sender)) senderXP = xp;
        else receiverXP = xp;
        senderConfirmed = false;
        receiverConfirmed = false;
    }

    public boolean isConfirmed(Player player) {
        return player.equals(sender) ? senderConfirmed : receiverConfirmed;
    }

    public void setConfirmed(Player player, boolean confirmed) {
        if (player.equals(sender)) senderConfirmed = confirmed;
        else receiverConfirmed = confirmed;
    }
}

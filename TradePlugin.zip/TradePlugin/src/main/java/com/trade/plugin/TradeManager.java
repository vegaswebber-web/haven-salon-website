package com.trade.plugin;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class TradeManager {

    private final TradePlugin plugin;
    private final Map<UUID, TradeSession> sessions = new HashMap<>();
    private final Map<UUID, Long> pendingRequests = new HashMap<>(); // request timeout

    public TradeManager(TradePlugin plugin) {
        this.plugin = plugin;
    }

    public void sendTradeRequest(Player sender, Player receiver) {
        // Zaten trade'de mi kontrol et
        if (isInTrade(sender)) {
            sender.sendMessage("§c✖ Zaten bir trade içindesin!");
            return;
        }
        if (isInTrade(receiver)) {
            sender.sendMessage("§c✖ " + receiver.getName() + " zaten bir trade içinde!");
            return;
        }

        // İstek zaten var mı kontrol et
        UUID key = getPairKey(sender, receiver);
        if (pendingRequests.containsKey(key)) {
            sender.sendMessage("§c✖ Zaten bu oyuncuya istek gönderdin!");
            return;
        }

        // İstek oluştur
        TradeSession session = new TradeSession(sender, receiver);
        sessions.put(sender.getUniqueId(), session);
        sessions.put(receiver.getUniqueId(), session);
        pendingRequests.put(key, System.currentTimeMillis());

        // Mesajlar
        sender.sendMessage("§a✔ §f" + receiver.getName() + " §7adlı oyuncuya trade isteği gönderildi.");
        receiver.sendMessage("");
        receiver.sendMessage("§6§l⇄ TRADE İSTEĞİ");
        receiver.sendMessage("§f" + sender.getName() + " §7sana trade isteği gönderdi!");
        receiver.sendMessage("§aKabul etmek için: §f/trade kabul " + sender.getName());
        receiver.sendMessage("§cReddetmek için: §f/trade reddet " + sender.getName());
        receiver.sendMessage("");

        // 60 saniye sonra iptal
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (sessions.containsKey(sender.getUniqueId())) {
                TradeSession s = sessions.get(sender.getUniqueId());
                if (s != null && s.getState() == TradeSession.State.PENDING) {
                    cancelTrade(sender, false);
                    sender.sendMessage("§c✖ Trade isteği zaman aşımına uğradı.");
                    receiver.sendMessage("§c✖ " + sender.getName() + " adlı oyuncunun trade isteği zaman aşımına uğradı.");
                }
            }
        }, 1200L); // 60 saniye
    }

    public void acceptTrade(Player receiver, Player sender) {
        TradeSession session = sessions.get(receiver.getUniqueId());
        if (session == null || session.getState() != TradeSession.State.PENDING) {
            receiver.sendMessage("§c✖ Aktif bir trade isteği bulunamadı!");
            return;
        }
        if (!session.getSender().equals(sender)) {
            receiver.sendMessage("§c✖ Bu oyuncudan bir trade isteği yok!");
            return;
        }

        session.setState(TradeSession.State.TRADING);
        pendingRequests.remove(getPairKey(sender, receiver));

        sender.sendMessage("§a✔ §f" + receiver.getName() + " §7trade isteğini kabul etti!");
        receiver.sendMessage("§a✔ §fTrade başladı!");

        // Trade GUI aç
        Bukkit.getScheduler().runTask(plugin, () -> {
            TradeGUI.openTradeGUI(plugin, session, sender);
            TradeGUI.openTradeGUI(plugin, session, receiver);
        });
    }

    public void declineTrade(Player receiver, Player sender) {
        TradeSession session = sessions.get(receiver.getUniqueId());
        if (session == null) {
            receiver.sendMessage("§c✖ Aktif bir trade isteği bulunamadı!");
            return;
        }

        cancelTrade(receiver, false);
        sender.sendMessage("§c✖ §f" + receiver.getName() + " §7trade isteğini reddetti.");
        receiver.sendMessage("§c✖ §fTrade isteği reddedildi.");
    }

    public void cancelTrade(Player player, boolean notify) {
        TradeSession session = sessions.get(player.getUniqueId());
        if (session == null) return;

        Player other = session.getOther(player);
        session.setState(TradeSession.State.CANCELLED);

        // Eşyaları geri ver
        returnItems(session);

        sessions.remove(session.getSender().getUniqueId());
        sessions.remove(session.getReceiver().getUniqueId());

        // GUI'leri kapat
        if (session.getSender().isOnline()) session.getSender().closeInventory();
        if (session.getReceiver().isOnline()) session.getReceiver().closeInventory();

        if (notify) {
            player.sendMessage("§c✖ Trade iptal edildi.");
            if (other != null && other.isOnline()) {
                other.sendMessage("§c✖ " + player.getName() + " trade'i iptal etti.");
            }
        }
    }

    public void confirmTrade(Player player) {
        TradeSession session = sessions.get(player.getUniqueId());
        if (session == null || session.getState() != TradeSession.State.TRADING) return;

        session.setConfirmed(player, true);
        Player other = session.getOther(player);

        player.sendMessage("§a✔ Trade'i onayladın! §7Diğer oyuncu onaylamasını bekliyorsun...");
        if (other != null && other.isOnline()) {
            other.sendMessage("§e⚠ §f" + player.getName() + " §7trade'i onayladı, sen de onaylamanı bekliyoruz!");
        }

        // GUI'leri güncelle
        TradeGUI.updateGUI(session, player);
        if (other != null) TradeGUI.updateGUI(session, other);

        if (session.bothConfirmed()) {
            completeTrade(session);
        }
    }

    private void completeTrade(TradeSession session) {
        session.setState(TradeSession.State.COMPLETED);
        Player sender = session.getSender();
        Player receiver = session.getReceiver();

        // GUI'leri kapat
        sender.closeInventory();
        receiver.closeInventory();

        // XP kontrolü
        if (session.getSenderXP() > 0 && sender.getTotalExperience() < session.getSenderXP()) {
            sender.sendMessage("§c✖ Yeterli XP'n yok! Trade iptal edildi.");
            receiver.sendMessage("§c✖ " + sender.getName() + " yeterli XP'ye sahip değil. Trade iptal edildi.");
            returnItems(session);
            sessions.remove(sender.getUniqueId());
            sessions.remove(receiver.getUniqueId());
            return;
        }
        if (session.getReceiverXP() > 0 && receiver.getTotalExperience() < session.getReceiverXP()) {
            receiver.sendMessage("§c✖ Yeterli XP'n yok! Trade iptal edildi.");
            sender.sendMessage("§c✖ " + receiver.getName() + " yeterli XP'ye sahip değil. Trade iptal edildi.");
            returnItems(session);
            sessions.remove(sender.getUniqueId());
            sessions.remove(receiver.getUniqueId());
            return;
        }

        // Eşyaları takas et
        for (ItemStack item : session.getSenderItems()) {
            if (item != null) receiver.getInventory().addItem(item);
        }
        for (ItemStack item : session.getReceiverItems()) {
            if (item != null) sender.getInventory().addItem(item);
        }

        // XP takas et
        if (session.getSenderXP() > 0) {
            sender.giveExp(-session.getSenderXP());
            receiver.giveExp(session.getSenderXP());
        }
        if (session.getReceiverXP() > 0) {
            receiver.giveExp(-session.getReceiverXP());
            sender.giveExp(session.getReceiverXP());
        }

        sessions.remove(sender.getUniqueId());
        sessions.remove(receiver.getUniqueId());

        sender.sendMessage("§a§l✔ TRADE TAMAMLANDI!");
        receiver.sendMessage("§a§l✔ TRADE TAMAMLANDI!");
    }

    private void returnItems(TradeSession session) {
        for (ItemStack item : session.getSenderItems()) {
            if (item != null && session.getSender().isOnline()) {
                session.getSender().getInventory().addItem(item);
            }
        }
        for (ItemStack item : session.getReceiverItems()) {
            if (item != null && session.getReceiver().isOnline()) {
                session.getReceiver().getInventory().addItem(item);
            }
        }
        session.getSenderItems().clear();
        session.getReceiverItems().clear();
    }

    public TradeSession getSession(Player player) {
        return sessions.get(player.getUniqueId());
    }

    public boolean isInTrade(Player player) {
        return sessions.containsKey(player.getUniqueId());
    }

    private UUID getPairKey(Player a, Player b) {
        // Sıralı UUID ile unique key
        String key = a.getUniqueId().toString().compareTo(b.getUniqueId().toString()) < 0
                ? a.getUniqueId() + "_" + b.getUniqueId()
                : b.getUniqueId() + "_" + a.getUniqueId();
        return UUID.nameUUIDFromBytes(key.getBytes());
    }
}

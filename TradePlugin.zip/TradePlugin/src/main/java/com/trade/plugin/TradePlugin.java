package com.trade.plugin;

import org.bukkit.plugin.java.JavaPlugin;

public class TradePlugin extends JavaPlugin {

    private static TradePlugin instance;
    private TradeManager tradeManager;

    @Override
    public void onEnable() {
        instance = this;
        tradeManager = new TradeManager(this);

        getServer().getPluginManager().registerEvents(new TradeListener(this), this);
        getCommand("trade").setExecutor(new TradeCommand(this));

        getLogger().info("TradePlugin aktif!");
    }

    @Override
    public void onDisable() {
        getLogger().info("TradePlugin devre disi!");
    }

    public static TradePlugin getInstance() {
        return instance;
    }

    public TradeManager getTradeManager() {
        return tradeManager;
    }
}

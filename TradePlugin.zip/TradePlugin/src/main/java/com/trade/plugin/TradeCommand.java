package com.trade.plugin;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TradeCommand implements CommandExecutor {

    private final TradePlugin plugin;

    public TradeCommand(TradePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cBu komutu sadece oyuncular kullanabilir!");
            return true;
        }

        Player player = (Player) sender;

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "kabul":
            case "accept":
                if (args.length < 2) {
                    player.sendMessage("§c✖ Kullanım: /trade kabul <oyuncu>");
                    return true;
                }
                Player acceptTarget = Bukkit.getPlayer(args[1]);
                if (acceptTarget == null) {
                    player.sendMessage("§c✖ Oyuncu bulunamadı!");
                    return true;
                }
                plugin.getTradeManager().acceptTrade(player, acceptTarget);
                break;

            case "reddet":
            case "decline":
            case "deny":
                if (args.length < 2) {
                    player.sendMessage("§c✖ Kullanım: /trade reddet <oyuncu>");
                    return true;
                }
                Player declineTarget = Bukkit.getPlayer(args[1]);
                if (declineTarget == null) {
                    player.sendMessage("§c✖ Oyuncu bulunamadı!");
                    return true;
                }
                plugin.getTradeManager().declineTrade(player, declineTarget);
                break;

            case "iptal":
            case "cancel":
                if (!plugin.getTradeManager().isInTrade(player)) {
                    player.sendMessage("§c✖ Aktif bir trade'in yok!");
                    return true;
                }
                plugin.getTradeManager().cancelTrade(player, true);
                break;

            default:
                // /trade <oyuncu> - trade isteği gönder
                Player target = Bukkit.getPlayer(args[0]);
                if (target == null) {
                    player.sendMessage("§c✖ Oyuncu bulunamadı: §f" + args[0]);
                    return true;
                }
                if (target.equals(player)) {
                    player.sendMessage("§c✖ Kendinle trade yapamazsın!");
                    return true;
                }
                plugin.getTradeManager().sendTradeRequest(player, target);
                break;
        }

        return true;
    }

    private void sendHelp(Player player) {
        player.sendMessage("§6§l--- Trade Komutları ---");
        player.sendMessage("§e/trade <oyuncu> §7- Trade isteği gönder");
        player.sendMessage("§e/trade kabul <oyuncu> §7- Trade isteğini kabul et");
        player.sendMessage("§e/trade reddet <oyuncu> §7- Trade isteğini reddet");
        player.sendMessage("§e/trade iptal §7- Trade'i iptal et");
        player.sendMessage("§7Veya §eShift + Sağ Klik §7ile oyuncuya trade isteği gönder.");
    }
}

package com.trade.plugin;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.EquipmentSlot;

public class TradeListener implements Listener {

    private final TradePlugin plugin;

    public TradeListener(TradePlugin plugin) {
        this.plugin = plugin;
    }

    // Sol Shift + Sol Klik ile oyuncuya tıklanınca trade isteği gönder
    @EventHandler
    public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
        if (!(event.getRightClicked() instanceof Player)) return;
        if (event.getHand() != EquipmentSlot.HAND) return;

        Player clicker = event.getPlayer();
        Player target = (Player) event.getRightClicked();

        // Shift + sağ klik kontrolü - oyunculara sağ tıklamak zaten shift ile çalışır
        if (!clicker.isSneaking()) return;

        event.setCancelled(true);

        if (clicker.equals(target)) {
            clicker.sendMessage("§c✖ Kendinle trade yapamazsın!");
            return;
        }

        plugin.getTradeManager().sendTradeRequest(clicker, target);
    }

    // Envanter tıklama olayları
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();

        String title = event.getView().getTitle();
        if (!title.contains("⇄") || !title.contains("Trade:")) return;

        event.setCancelled(true);

        TradeSession session = plugin.getTradeManager().getSession(player);
        if (session == null || session.getState() != TradeSession.State.TRADING) return;

        int slot = event.getRawSlot();
        ItemStack clicked = event.getCurrentItem();

        // Kendi slotlarına tıkladı - eşya ekle/çıkar
        if (TradeGUI.isMySlotPublic(slot)) {
            // Slottaki eşya varsa geri al
            if (clicked != null && !isGlassPane(clicked)) {
                session.getMyItems(player).remove(clicked);
                player.getInventory().addItem(clicked);
                session.setSenderConfirmed(false);
                session.setReceiverConfirmed(false);
                TradeGUI.updateGUI(session, player);
                TradeGUI.updateGUI(session, session.getOther(player));
            }
            // Elindeki eşyayı ekle
            else if (event.getCursor() != null && event.getCursor().getType() != org.bukkit.Material.AIR) {
                ItemStack cursor = event.getCursor().clone();
                session.getMyItems(player).add(cursor);
                player.setItemOnCursor(null);
                session.setSenderConfirmed(false);
                session.setReceiverConfirmed(false);
                TradeGUI.updateGUI(session, player);
                TradeGUI.updateGUI(session, session.getOther(player));
            }
            return;
        }

        // Karşı tarafın slotları - sadece görüntü, tıklanamaz
        if (TradeGUI.isTheirSlotPublic(slot)) {
            return;
        }

        // Alt envanter - eşyayı trade'e ekle
        if (slot >= 54 && clicked != null && clicked.getType() != org.bukkit.Material.AIR) {
            if (!isGlassPane(clicked)) {
                if (session.getMyItems(player).size() >= 13) {
                    player.sendMessage("§c✖ Trade'e en fazla 13 eşya ekleyebilirsin!");
                    return;
                }
                ItemStack toAdd = clicked.clone();
                session.getMyItems(player).add(toAdd);
                player.getInventory().remove(clicked);
                session.setSenderConfirmed(false);
                session.setReceiverConfirmed(false);
                TradeGUI.updateGUI(session, player);
                TradeGUI.updateGUI(session, session.getOther(player));
            }
            return;
        }

        // XP Ekle butonu
        if (slot == TradeGUI.XP_ADD_SLOT) {
            int amount = 1;
            if (event.isShiftClick()) amount = 100;
            else if (event.isRightClick()) amount = 10;

            int current = session.getMyXP(player);
            int playerXP = player.getTotalExperience();
            int newXP = Math.min(current + amount, playerXP);
            session.setMyXP(player, newXP);

            player.sendMessage("§a✔ §7Trade XP'si: §f" + newXP);
            TradeGUI.updateGUI(session, player);
            TradeGUI.updateGUI(session, session.getOther(player));
            return;
        }

        // XP Çıkar butonu
        if (slot == TradeGUI.XP_REMOVE_SLOT) {
            int amount = 1;
            if (event.isShiftClick()) amount = 100;
            else if (event.isRightClick()) amount = 10;

            int current = session.getMyXP(player);
            int newXP = Math.max(0, current - amount);
            session.setMyXP(player, newXP);

            player.sendMessage("§c✖ §7Trade XP'si: §f" + newXP);
            TradeGUI.updateGUI(session, player);
            TradeGUI.updateGUI(session, session.getOther(player));
            return;
        }

        // Onay butonu
        if (slot == TradeGUI.CONFIRM_SLOT) {
            if (session.isConfirmed(player)) {
                player.sendMessage("§c✖ Zaten onayladın!");
                return;
            }
            plugin.getTradeManager().confirmTrade(player);
            return;
        }

        // İptal butonu
        if (slot == TradeGUI.CANCEL_SLOT) {
            plugin.getTradeManager().cancelTrade(player, true);
            return;
        }
    }

    // Sürüklemeyi engelle
    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        String title = event.getView().getTitle();
        if (title.contains("⇄") && title.contains("Trade:")) {
            event.setCancelled(true);
        }
    }

    // Envanter kapandığında trade iptal et
    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player)) return;
        Player player = (Player) event.getPlayer();

        String title = event.getView().getTitle();
        if (!title.contains("⇄") || !title.contains("Trade:")) return;

        TradeSession session = plugin.getTradeManager().getSession(player);
        if (session != null && session.getState() == TradeSession.State.TRADING) {
            plugin.getTradeManager().cancelTrade(player, true);
        }
    }

    // Oyuncu çıkarsa trade iptal et
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        TradeSession session = plugin.getTradeManager().getSession(player);
        if (session != null) {
            plugin.getTradeManager().cancelTrade(player, true);
        }
    }

    private boolean isGlassPane(ItemStack item) {
        if (item == null) return false;
        String name = item.getType().name();
        return name.contains("GLASS_PANE") || item.getType() == org.bukkit.Material.BARRIER
                || item.getType() == org.bukkit.Material.LIME_DYE
                || item.getType() == org.bukkit.Material.RED_DYE
                || item.getType() == org.bukkit.Material.EXPERIENCE_BOTTLE
                || item.getType() == org.bukkit.Material.GREEN_WOOL
                || item.getType() == org.bukkit.Material.LIME_WOOL;
    }
}

package com.timber.plugin;

import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;

public class TreeListener implements Listener {

    private final TimberPlugin plugin;
    private static final Set<Material> LOG_TYPES = new HashSet<>();
    private static final Set<Material> AXE_TYPES = new HashSet<>();

    static {
        LOG_TYPES.add(Material.OAK_LOG);
        LOG_TYPES.add(Material.SPRUCE_LOG);
        LOG_TYPES.add(Material.BIRCH_LOG);
        LOG_TYPES.add(Material.JUNGLE_LOG);
        LOG_TYPES.add(Material.ACACIA_LOG);
        LOG_TYPES.add(Material.DARK_OAK_LOG);
        LOG_TYPES.add(Material.MANGROVE_LOG);
        LOG_TYPES.add(Material.CHERRY_LOG);
        LOG_TYPES.add(Material.BAMBOO_BLOCK);
        LOG_TYPES.add(Material.CRIMSON_STEM);
        LOG_TYPES.add(Material.WARPED_STEM);

        AXE_TYPES.add(Material.WOODEN_AXE);
        AXE_TYPES.add(Material.STONE_AXE);
        AXE_TYPES.add(Material.IRON_AXE);
        AXE_TYPES.add(Material.GOLDEN_AXE);
        AXE_TYPES.add(Material.DIAMOND_AXE);
        AXE_TYPES.add(Material.NETHERITE_AXE);
    }

    public TreeListener(TimberPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();

        if (!LOG_TYPES.contains(block.getType())) return;

        ItemStack tool = player.getInventory().getItemInMainHand();
        if (!AXE_TYPES.contains(tool.getType())) return;

        if (player.getGameMode() == GameMode.CREATIVE) return;

        List<Block> logs = findConnectedLogs(block);

        int durabilityDamage = logs.size() - 1;
        if (durabilityDamage > 0) {
            damageTool(player, tool, durabilityDamage);
        }

        for (Block log : logs) {
            if (!log.equals(block)) {
                log.breakNaturally(tool);
            }
        }
    }

    private List<Block> findConnectedLogs(Block startBlock) {
        Material logType = startBlock.getType();
        List<Block> logs = new ArrayList<>();
        Set<Block> visited = new HashSet<>();
        Queue<Block> queue = new LinkedList<>();

        queue.add(startBlock);
        visited.add(startBlock);

        while (!queue.isEmpty() && logs.size() < 500) {
            Block current = queue.poll();
            logs.add(current);

            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = 0; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        Block neighbor = current.getRelative(dx, dy, dz);
                        if (!visited.contains(neighbor) && neighbor.getType() == logType) {
                            visited.add(neighbor);
                            queue.add(neighbor);
                        }
                    }
                }
            }
        }
        return logs;
    }

    private void damageTool(Player player, ItemStack tool, int damage) {
        if (tool.getEnchantmentLevel(Enchantment.UNBREAKING) > 0) {
            int unbreakingLevel = tool.getEnchantmentLevel(Enchantment.UNBREAKING);
            int actualDamage = 0;
            for (int i = 0; i < damage; i++) {
                if (Math.random() > (double) unbreakingLevel / (unbreakingLevel + 1)) {
                    actualDamage++;
                }
            }
            damage = actualDamage;
        }

        if (damage <= 0) return;

        short currentDurability = tool.getDurability();
        short maxDurability = tool.getType().getMaxDurability();
        short newDurability = (short) (currentDurability + damage);

        if (newDurability >= maxDurability) {
            player.getInventory().setItemInMainHand(null);
            player.getWorld().playSound(player.getLocation(), org.bukkit.Sound.ENTITY_ITEM_BREAK, 1.0f, 1.0f);
        } else {
            tool.setDurability(newDurability);
        }
    }
}

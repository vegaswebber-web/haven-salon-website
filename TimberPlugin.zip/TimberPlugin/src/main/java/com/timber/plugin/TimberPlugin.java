package com.timber.plugin;

import org.bukkit.plugin.java.JavaPlugin;

public class TimberPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(new TreeListener(this), this);
        getLogger().info("TimberPlugin aktif!");
    }

    @Override
    public void onDisable() {
        getLogger().info("TimberPlugin devre disi!");
    }
}
